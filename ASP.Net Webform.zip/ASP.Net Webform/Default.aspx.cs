﻿using System;
using System.Web.UI;
using System.IO;
using System.Xml;
using ASPSnippets.TwitterAPI;


namespace Assignment_2
{
    public partial class _Default : Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            TwitterConnect.API_Key = "vWfByTaCXJ8DQq4WBbZ0rN5o7";
            TwitterConnect.API_Secret = "EqQDugg3cONEFfGHcVOqFTJo7J3aHTbO6E6S0iFF6Obl2S9Chz";
            

            if (!IsPostBack)
            {
                HideAllExceptMap();

                GetAllRecordsFromXml();
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(UserDropList.SelectedValue == "-1")
            {
                HideAllExceptMap();
            }
            else if(UserDropList.SelectedValue == "Patient")
            {
                Patient(); 
            }
            else if (UserDropList.SelectedValue == "Collaborator")
            {
                CollabRegistration();  
            }
        }

        protected void SocialsRadioList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(SocialsRadioList.SelectedValue == "Tweet")
            {
                TweetPanel.Visible = true;
                FBPanel.Visible = false;
            }
            else if(SocialsRadioList.SelectedValue == "Facebook")
            {
                TweetPanel.Visible = false;
                FBPanel.Visible = true;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            string filename = Server.MapPath("Collaborators.xml");
            if (File.Exists(filename) == true)
            {
                //add a new record on button submit

                XmlDocument xdoc = new XmlDocument();

                xdoc.Load(Server.MapPath("Collaborators.xml"));

                XmlElement Collaborator = xdoc.CreateElement("Collaborator");

                //Create each element
                XmlElement FirstName = xdoc.CreateElement("FirstName");
                XmlText xmlFirstName = xdoc.CreateTextNode(FirstNameTxtBox.Text);

                XmlElement LastName = xdoc.CreateElement("LastName");
                XmlText xmlLastName = xdoc.CreateTextNode(LastNameTxtBox.Text);

                XmlElement Address = xdoc.CreateElement("Address");
                XmlText xmlAddress = xdoc.CreateTextNode(AddressTxtBox.Text);

                XmlElement Contact = xdoc.CreateElement("Contact");
                XmlText xmlContact = xdoc.CreateTextNode(ContactTxtBox.Text);

                XmlElement Availability = xdoc.CreateElement("Availability");
                XmlText xmlAvailability = xdoc.CreateTextNode(AvailabilityTxtBox.Text);

                XmlElement AdditionalInfo = xdoc.CreateElement("AdditionalInfo");
                XmlText xmlAdditionalInfo = xdoc.CreateTextNode(AdditionalTxtBox.Text);

                //Formatting each element

                FirstName.AppendChild(xmlFirstName);
                LastName.AppendChild(xmlLastName);
                Address.AppendChild(xmlAddress);
                Contact.AppendChild(xmlContact);
                Availability.AppendChild(xmlAvailability);
                AdditionalInfo.AppendChild(xmlAdditionalInfo);

                //Appending each element

                Collaborator.AppendChild(FirstName);
                Collaborator.AppendChild(LastName);
                Collaborator.AppendChild(Address);
                Collaborator.AppendChild(Contact);
                Collaborator.AppendChild(Availability);
                Collaborator.AppendChild(AdditionalInfo);

                //Append Collaborator in the Document file

                xdoc.DocumentElement.AppendChild(Collaborator);

                //Save the XML file
                xdoc.Save(Server.MapPath("Collaborators.xml"));

            }
            else
            {
                //create a new File and structure if one does not exist
                
                XmlTextWriter xtw = new XmlTextWriter(filename, null);
                
                xtw.WriteStartDocument();

                xtw.WriteStartElement("Collaborators");

                xtw.WriteStartElement("Collaborator");
                
                //Create a new element
                xtw.WriteElementString("FirstName" , FirstNameTxtBox.Text);
                xtw.WriteElementString("LastName", LastNameTxtBox.Text);
                xtw.WriteElementString("Address", AddressTxtBox.Text);
                xtw.WriteElementString("Contact", ContactTxtBox.Text);
                xtw.WriteElementString("Availability", AvailabilityTxtBox.Text);
                xtw.WriteElementString("AdditionalInfo", AdditionalTxtBox.Text);

                //close Element and document

                xtw.WriteEndElement();

                xtw.WriteEndElement();

                xtw.WriteEndDocument();

                //Close the stream after completion

                xtw.Close();
            }
        }

        //Retrieve XML records from file and paste into gridview
        private void GetAllRecordsFromXml()
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            ds.ReadXml(Server.MapPath("Collaborators.xml"));

            gridview1.DataSource = ds;
            gridview1.DataBind();
        }

        protected void ShowCollaborators_Click(object sender, EventArgs e)
        {
            gridview1.Visible = true;
            ShowCollaborators.Visible = false;
            HideCollaborators.Visible = true;
        }

        protected void HideCollaborators_Click(object sender, EventArgs e)
        {
            gridview1.Visible = false;
            ShowCollaborators.Visible = true;
            HideCollaborators.Visible = false;
        }
        //Hide/Show objects function
        private void HideAllExceptMap()
        {
            SocialsRadioList.Visible = false;
            SocialsRadioList.ClearSelection();

            TweetPanel.Visible = false;
            FBPanel.Visible = false;

            CollaboratorReg.Visible = false;
            FirstNameLabel.Visible = false;
            FirstNameTxtBox.Visible = false;
            LastNameLabel.Visible = false;
            LastNameTxtBox.Visible = false;
            AddressLabel.Visible = false;
            AddressTxtBox.Visible = false;
            ContactLabel.Visible = false;
            ContactTxtBox.Visible = false;
            AvailabilityLabel.Visible = false;
            AvailabilityTxtBox.Visible = false;
            AdditionalLabel.Visible = false;
            AdditionalTxtBox.Visible = false;
            btnSubmit.Visible = false;
            gridview1.Visible = false;
            ShowCollaborators.Visible = false;
            HideCollaborators.Visible = false;
        }
        private void Patient()
        {
            SocialsRadioList.Visible = true;
            SocialsRadioList.ClearSelection();

            TweetPanel.Visible = false;
            FBPanel.Visible = false;
            
            CollaboratorReg.Visible = false;
            FirstNameLabel.Visible = false;
            FirstNameTxtBox.Visible = false;
            LastNameLabel.Visible = false;
            LastNameTxtBox.Visible = false;
            AddressLabel.Visible = false;
            AddressTxtBox.Visible = false;
            ContactLabel.Visible = false;
            ContactTxtBox.Visible = false;
            AvailabilityLabel.Visible = false;
            AvailabilityTxtBox.Visible = false;
            AdditionalLabel.Visible = false;
            AdditionalTxtBox.Visible = false;
            btnSubmit.Visible = false;
            gridview1.Visible = false;
            ShowCollaborators.Visible = true;
        }

        private void CollabRegistration()
        {
            SocialsRadioList.Visible = false;
            SocialsRadioList.ClearSelection();

            TweetPanel.Visible = false;
            FBPanel.Visible = false;

            CollaboratorReg.Visible = true;
            FirstNameLabel.Visible = true;
            FirstNameTxtBox.Visible = true;
            LastNameLabel.Visible = true;
            LastNameTxtBox.Visible = true;
            AddressLabel.Visible = true;
            AddressTxtBox.Visible = true;
            ContactLabel.Visible = true;
            ContactTxtBox.Visible = true;
            AvailabilityLabel.Visible = true;
            AvailabilityTxtBox.Visible = true;
            AdditionalLabel.Visible = true;
            AdditionalTxtBox.Visible = true;
            btnSubmit.Visible = true;
            gridview1.Visible = false;
            ShowCollaborators.Visible = true; 
        }
    }
}